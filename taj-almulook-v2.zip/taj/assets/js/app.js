// ================================
// TAJ ALMULOOK — app.js
// ================================

// Navbar scroll
window.addEventListener("scroll",()=>{
  const nav=document.querySelector(".navbar");
  if(!nav)return;
  if(window.scrollY>80){nav.style.background="#000";nav.style.boxShadow="0 4px 20px rgba(0,0,0,.6)";}
  else{nav.style.background="rgba(0,0,0,.9)";nav.style.boxShadow="none";}
});

// Mobile menu
const ham=document.querySelector(".hamburger");
const mob=document.querySelector(".mobile-menu");
if(ham&&mob){ham.onclick=()=>mob.classList.toggle("open");}

// Card animations
const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting){e.target.style.opacity="1";e.target.style.transform="translateY(0)";}});
},{threshold:.1});
document.querySelectorAll(".service-card,.product-card,.kpi-card,.admin-stat-card").forEach(c=>{
  c.style.opacity="0";c.style.transform="translateY(40px)";c.style.transition=".5s";
  observer.observe(c);
});

// Back to top
const topBtn=document.createElement("button");
topBtn.innerHTML='<i class="fa-solid fa-arrow-up"></i>';
topBtn.id="topBtn";
topBtn.style.cssText="position:fixed;bottom:24px;left:24px;width:46px;height:46px;border:none;border-radius:50%;background:#d4af37;color:#000;font-size:16px;cursor:pointer;display:none;z-index:990;transition:.3s;";
document.body.appendChild(topBtn);
window.addEventListener("scroll",()=>{topBtn.style.display=window.scrollY>400?"flex":"none";topBtn.style.alignItems="center";topBtn.style.justifyContent="center";});
topBtn.onclick=()=>window.scrollTo({top:0,behavior:"smooth"});

// Toast
function showToast(msg,type="success"){
  let t=document.querySelector(".toast");
  if(!t){t=document.createElement("div");t.className="toast";document.body.appendChild(t);}
  t.textContent=msg;t.className="toast show "+(type==="error"?"error":"");
  setTimeout(()=>t.classList.remove("show"),3200);
}
window.showToast=showToast;

// Cart (localStorage)
let cart=JSON.parse(localStorage.getItem("taj_cart")||"[]");
function updateCartBadge(){
  const b=document.querySelector(".cart-count");
  if(b)b.textContent=cart.length;
}
function addToCart(id,name,price){
  let existing = cart.find(i=>i.id===id);
  if(existing){ existing.qty=(existing.qty||1)+1; }
  else{ cart.push({id,name,price,qty:1}); }
  localStorage.setItem("taj_cart",JSON.stringify(cart));
  updateCartBadge();
  showToast("✅ أُضيف للسلة: "+name);
  // زر عرض السلة
  let viewBtn = document.getElementById('viewCartBtn');
  if(!viewBtn){
    viewBtn = document.createElement('button');
    viewBtn.id='viewCartBtn';
    viewBtn.textContent='🛒 عرض السلة';
    viewBtn.style.cssText='position:fixed;bottom:80px;left:24px;background:var(--gold);color:#000;border:none;padding:10px 20px;border-radius:8px;font-weight:800;cursor:pointer;z-index:991;font-family:Cairo,sans-serif;font-size:13px';
    viewBtn.onclick=()=>location.href='cart.html';
    document.body.appendChild(viewBtn);
  }
}
window.addToCart=addToCart;
updateCartBadge();

// Search filter
function searchTable(inputId,tableId){
  const val=document.getElementById(inputId).value.toLowerCase();
  document.querySelectorAll("#"+tableId+" tbody tr").forEach(r=>{
    r.style.display=r.innerText.toLowerCase().includes(val)?"":"none";
  });
}
window.searchTable=searchTable;

// Warranty check
const warrantyDB={
  "TM001":{ name:"أحمد محمد العمري", car:"تويوتا كامري 2023", product:"فيلم حماية 3M PPF", service:"تركيب PPF كامل", tech:"فيصل الغامدي", install:"2024-01-15", expire:"2026-01-15", status:"ساري" },
  "TM002":{ name:"خالد سعد الشمري", car:"لكزس ES350 2022", product:"شاشة Pioneer DMH-9600", service:"تركيب شاشة أندرويد", tech:"محمد الزهراني", install:"2024-03-10", expire:"2025-03-10", status:"ساري" },
  "TM003":{ name:"سارة عبدالله الحربي", car:"نيسان باترول 2024", product:"عازل حراري 3M Ceramic", service:"تظليل كامل سيراميك", tech:"عمر السبيعي", install:"2023-08-22", expire:"2024-08-22", status:"منتهي" },
};
function checkWarranty(){
  const code=document.getElementById("warrantyCode").value.trim().toUpperCase();
  const res=document.getElementById("warrantyResult");
  if(!code){showToast("أدخل رقم الضمان","error");return;}
  const w=warrantyDB[code];
  if(w){
    const valid=w.status==="ساري";
    res.style.display="block";
    res.className="warranty-result "+(valid?"warranty-valid":"warranty-invalid");
    res.innerHTML=`<h3>${valid?"✅ الضمان ساري":"❌ الضمان منتهي"}</h3>
    <div class="warranty-details">
      <div class="warranty-detail-item"><label>اسم العميل</label><span>${w.name}</span></div>
      <div class="warranty-detail-item"><label>السيارة</label><span>${w.car}</span></div>
      <div class="warranty-detail-item"><label>المنتج</label><span>${w.product}</span></div>
      <div class="warranty-detail-item"><label>الخدمة</label><span>${w.service}</span></div>
      <div class="warranty-detail-item"><label>الفني</label><span>${w.tech}</span></div>
      <div class="warranty-detail-item"><label>تاريخ التركيب</label><span>${w.install}</span></div>
      <div class="warranty-detail-item"><label>تاريخ الانتهاء</label><span>${w.expire}</span></div>
      <div class="warranty-detail-item"><label>الحالة</label><span class="badge ${valid?"badge-green":"badge-red"}">${w.status}</span></div>
    </div>`;
  } else {
    res.style.display="block";
    res.className="warranty-result warranty-invalid";
    res.innerHTML="<h3>❌ رقم الضمان غير موجود</h3><p style='color:#888;font-size:14px;margin-top:8px'>تأكد من الرقم أو تواصل مع المحل</p>";
  }
}
window.checkWarranty=checkWarranty;

// Booking submit
function submitBooking(e){
  if(e)e.preventDefault();
  showToast("✅ تم تأكيد الحجز! سيتم التواصل معك قريباً");
  return false;
}
window.submitBooking=submitBooking;

// Contact submit
function submitContact(e){
  if(e)e.preventDefault();
  showToast("✅ تم إرسال رسالتك بنجاح!");
  return false;
}
window.submitContact=submitContact;

// Category filter (shop)
function filterCat(btn,cat){
  document.querySelectorAll(".cat-tab").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");
  document.querySelectorAll(".product-card").forEach(c=>{
    c.style.display=(cat==="all"||c.dataset.cat===cat)?"block":"none";
  });
}
window.filterCat=filterCat;

// Stats counter animation
function animateCounters(){
  document.querySelectorAll(".stat-num").forEach(el=>{
    const target=parseInt(el.dataset.target);
    let count=0;const step=Math.ceil(target/60);
    const t=setInterval(()=>{count=Math.min(count+step,target);el.textContent=count.toLocaleString("ar-SA");if(count>=target)clearInterval(t);},30);
  });
}
const statsObs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting){animateCounters();statsObs.disconnect();}});
},{threshold:.3});
const statsSec=document.querySelector(".stats-section");
if(statsSec)statsObs.observe(statsSec);
