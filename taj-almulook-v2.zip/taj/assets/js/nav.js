// nav.js - dynamic nav active state
document.querySelectorAll(".navbar ul li a").forEach(a=>{
  if(a.href===window.location.href)a.style.color="var(--gold)";
});
