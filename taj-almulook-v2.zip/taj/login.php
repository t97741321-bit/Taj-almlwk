<?php session_start(); $err=isset($_GET['error'])?true:false; ?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>تسجيل الدخول | تاج الملوك</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
</head><body>
<div class="auth-page">
<div class="auth-card">
  <div class="auth-logo">
    <img src="assets/images/logo.png" alt="تاج الملوك">
    <h2>تاج الملوك</h2>
    <p>تسجيل الدخول إلى حسابك</p>
  </div>
  <?php if($err): ?><div style="background:rgba(224,0,36,.1);border:1px solid rgba(224,0,36,.3);color:#f87171;padding:12px;border-radius:8px;margin-bottom:18px;font-size:13px;text-align:center">❌ البريد أو كلمة المرور غير صحيحة</div><?php endif; ?>
  <form class="auth-form" action="api/login.php" method="POST">
    <div class="form-group"><label>البريد الإلكتروني</label><input type="email" name="email" placeholder="example@email.com" required></div>
    <div class="form-group"><label>كلمة المرور</label><input type="password" name="password" placeholder="••••••••" required></div>
    <button type="submit" class="btn-gold" style="width:100%;padding:13px;font-size:15px;margin-top:6px"><i class="fa-solid fa-right-to-bracket"></i> دخول</button>
  </form>
  <div class="auth-footer">ليس لديك حساب؟ <a href="register.php">إنشاء حساب</a></div>
  <div class="auth-footer" style="margin-top:8px"><a href="index.html" style="color:var(--gray)"><i class="fa-solid fa-arrow-right"></i> العودة للرئيسية</a></div>
  <div style="margin-top:20px;background:#111;border:1px solid #222;border-radius:8px;padding:14px;font-size:12px;color:#555;text-align:center">
    <strong style="color:var(--gold)">بيانات تجريبية:</strong><br>
    admin@taj.com / password
  </div>
</div>
</div>
<script src="assets/js/app.js"></script>
</body></html>