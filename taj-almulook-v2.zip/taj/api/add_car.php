<?php session_start();require_once("../database/config.php");
if(!isset($_SESSION['user'])){header("Location: ../login.php");exit;}
$uid=(int)$_SESSION['user'];
$brand=mysqli_real_escape_string($conn,$_POST['brand']);
$model=mysqli_real_escape_string($conn,$_POST['model']);
$year=mysqli_real_escape_string($conn,$_POST['year']);
$color=mysqli_real_escape_string($conn,$_POST['color']);
$plate=mysqli_real_escape_string($conn,$_POST['plate']);
$vin=mysqli_real_escape_string($conn,$_POST['vin']);
mysqli_query($conn,"INSERT INTO cars(user_id,brand,model,year,color,plate,vin) VALUES($uid,'$brand','$model','$year','$color','$plate','$vin')");
header("Location: ../customer/cars.php");
