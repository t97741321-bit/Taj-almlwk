<?php
session_start();
require_once("../database/config.php");
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email=mysqli_real_escape_string($conn,$_POST['email']);
  $pass=$_POST['password'];
  $res=mysqli_query($conn,"SELECT * FROM users WHERE email='$email' LIMIT 1");
  if($row=mysqli_fetch_assoc($res)){
    if(password_verify($pass,$row['password'])||$pass===$row['password']){
      $_SESSION['user']=$row['id'];
      $_SESSION['name']=$row['fullname'];
      $_SESSION['role']=$row['role'];
      if($row['role']==='admin')header("Location: ../admin/dashboard.php");
      else header("Location: ../customer/dashboard.php");
      exit;
    }
  }
  header("Location: ../login.php?error=1");
}
?>
