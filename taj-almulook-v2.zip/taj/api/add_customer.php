<?php session_start();require_once("../database/config.php");
$fn=mysqli_real_escape_string($conn,$_POST['fullname']);
$em=mysqli_real_escape_string($conn,$_POST['email']);
$ph=mysqli_real_escape_string($conn,$_POST['phone']);
$pw=password_hash($_POST['password'],PASSWORD_DEFAULT);
mysqli_query($conn,"INSERT INTO users(fullname,email,phone,password,role) VALUES('$fn','$em','$ph','$pw','customer')");
header("Location: ../admin/customers.php");
