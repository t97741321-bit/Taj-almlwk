<?php session_start();require_once("../database/config.php");
if(!isset($_SESSION['user'])){header("Location: ../login.php");exit;}
$uid=(int)$_SESSION['user'];
$fn=mysqli_real_escape_string($conn,$_POST['fullname']);
$ph=mysqli_real_escape_string($conn,$_POST['phone']);
mysqli_query($conn,"UPDATE users SET fullname='$fn',phone='$ph' WHERE id=$uid");
$_SESSION['name']=$fn;
header("Location: ../customer/profile.php");
