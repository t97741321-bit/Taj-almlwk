<?php
session_start();
require_once("../database/config.php");
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=mysqli_real_escape_string($conn,$_POST['fullname']);
  $email=mysqli_real_escape_string($conn,$_POST['email']);
  $phone=mysqli_real_escape_string($conn,$_POST['phone']);
  $pass=password_hash($_POST['password'],$_PASSWORD_DEFAULT);
  $check=mysqli_query($conn,"SELECT id FROM users WHERE email='$email'");
  if(mysqli_num_rows($check)>0){header("Location: ../register.php?error=exists");exit;}
  mysqli_query($conn,"INSERT INTO users(fullname,email,phone,password,role) VALUES('$name','$email','$phone','$pass','customer')");
  $id=mysqli_insert_id($conn);
  $_SESSION['user']=$id;$_SESSION['name']=$name;$_SESSION['role']='customer';
  header("Location: ../customer/dashboard.php");
}
?>
