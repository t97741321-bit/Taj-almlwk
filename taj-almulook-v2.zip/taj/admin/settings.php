<?php
session_start();
if(!isset($_SESSION['user'])||$_SESSION['role']!='admin'){header("Location: ../login.php");exit;}
$admin_name=$_SESSION['name']??'المدير';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>الإعدادات | تاج الملوك</title>
</head><body>
<div class='admin-layout'>
<div class="admin-sidebar">
  <div class="admin-sidebar-logo">
    <img src="../assets/images/logo.png" alt="تاج الملوك">
    <h3>تاج الملوك</h3>
  </div>
  <nav class="admin-nav">
    <div class="nav-group">الرئيسية</div>
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <div class="nav-group">إدارة</div>
    <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>"><i class="fa-solid fa-users"></i> العملاء</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> السيارات</a>
    <a href="products.php" class="<?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>"><i class="fa-solid fa-box"></i> المنتجات</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> الحجوزات</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> الضمانات</a>
    <div class="nav-group">التقارير</div>
    <a href="reports.php" class="<?= basename($_SERVER['PHP_SELF'])=='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-bar"></i> التقارير</a>
    <a href="admins.php" class="<?= basename($_SERVER['PHP_SELF'])=='admins.php'?'active':'' ?>"><i class="fa-solid fa-user-shield"></i> المسؤولون</a>
    <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>"><i class="fa-solid fa-gear"></i> الإعدادات</a>
    <div class="nav-group">الحساب</div>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<?php require_once("../database/config.php");
$s=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM settings LIMIT 1"));
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=mysqli_real_escape_string($conn,$_POST['shop_name']);
  $ph=mysqli_real_escape_string($conn,$_POST['phone']);
  $em=mysqli_real_escape_string($conn,$_POST['email']);
  $ad=mysqli_real_escape_string($conn,$_POST['address']);
  $wa=mysqli_real_escape_string($conn,$_POST['whatsapp']);
  $ig=mysqli_real_escape_string($conn,$_POST['instagram']);
  mysqli_query($conn,"UPDATE settings SET shop_name='$name',phone='$ph',email='$em',address='$ad',whatsapp='$wa',instagram='$ig' WHERE id=1");
  echo "<script>showToast('✅ تم حفظ الإعدادات')</script>";
}
?>
<div class="admin-main">
  <div class="admin-topbar"><h1>⚙️ <span>إعدادات الموقع</span></h1></div>
  <div style="max-width:700px">
    <div class="form-card">
      <div class="form-title">معلومات المحل</div>
      <form method="POST">
        <div class="form-row">
          <div class="form-group"><label>اسم المحل</label><input class="input-field" type="text" name="shop_name" value="<?=htmlspecialchars($s['shop_name']??'تاج الملوك')?>"></div>
          <div class="form-group"><label>رقم الهاتف</label><input class="input-field" type="text" name="phone" value="<?=$s['phone']??''?>"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>البريد الإلكتروني</label><input class="input-field" type="email" name="email" value="<?=$s['email']??''?>"></div>
          <div class="form-group"><label>واتساب</label><input class="input-field" type="text" name="whatsapp" value="<?=$s['whatsapp']??''?>"></div>
        </div>
        <div class="form-group full"><label>العنوان</label><textarea class="input-field" name="address" style="height:70px;resize:none"><?=$s['address']??''?></textarea></div>
        <div class="form-row">
          <div class="form-group"><label>إنستغرام</label><input class="input-field" type="text" name="instagram" value="<?=$s['instagram']??''?>"></div>
          <div class="form-group"><label>سناب شات</label><input class="input-field" type="text" name="snapchat" value="<?=$s['snapchat']??''?>"></div>
        </div>
        <button type="submit" class="btn-gold" style="padding:12px 28px"><i class="fa-solid fa-save"></i> حفظ الإعدادات</button>
      </form>
    </div>
  </div>
</div>
</div>
<script src="../assets/js/app.js"></script></body></html>