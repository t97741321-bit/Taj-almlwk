<?php
session_start();
if(!isset($_SESSION['user'])||$_SESSION['role']!='admin'){header("Location: ../login.php");exit;}
require_once("../database/config.php");
$users=mysqli_query($conn,"SELECT * FROM users WHERE role='customer'");
$cars=mysqli_query($conn,"SELECT c.*,u.fullname FROM cars c LEFT JOIN users u ON c.user_id=u.id");
$msg='';
if(isset($_POST['save'])){
  $number="TM".time();
  $user=(int)$_POST['user'];
  $car=(int)$_POST['car'];
  $service=mysqli_real_escape_string($conn,$_POST['service']);
  $product=mysqli_real_escape_string($conn,$_POST['product']);
  $tech=mysqli_real_escape_string($conn,$_POST['tech']);
  $start=$_POST['start'];$end=$_POST['end'];$status="ساري";
  mysqli_query($conn,"INSERT INTO warranties(warranty_no,user_id,car_id,service,product,technician,install_date,expire_date,status) VALUES('$number',$user,$car,'$service','$product','$tech','$start','$end','$status')");
  $msg='<div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;padding:12px;border-radius:8px;margin-bottom:16px">✅ تم إنشاء الضمان: '.$number.'</div>';
}
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>إضافة ضمان | تاج الملوك</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
</head><body>
<div style="max-width:700px;margin:60px auto;padding:20px">
  <div style="display:flex;align-items:center;gap:14px;margin-bottom:28px">
    <a href="warranties.php" class="btn-outline btn-sm"><i class="fa-solid fa-arrow-right"></i> رجوع</a>
    <h1 style="font-size:22px;font-weight:900">🛡️ إضافة ضمان جديد</h1>
  </div>
  <?= $msg ?>
  <div class="form-card">
    <form method="POST">
      <div class="form-row">
        <div class="form-group"><label>العميل</label>
          <select class="input-field" name="user">
            <?php mysqli_data_seek($users,0); while($u=mysqli_fetch_assoc($users)): ?>
            <option value="<?=$u['id']?>"><?=htmlspecialchars($u['fullname'])?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group"><label>السيارة</label>
          <select class="input-field" name="car">
            <?php while($c=mysqli_fetch_assoc($cars)): ?>
            <option value="<?=$c['id']?>"><?=htmlspecialchars($c['brand'].' '.$c['model'].' - '.($c['fullname']??''))?></option>
            <?php endwhile; ?>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>الخدمة</label><input class="input-field" name="service" placeholder="نوع الخدمة" required></div>
        <div class="form-group"><label>المنتج</label><input class="input-field" name="product" placeholder="اسم المنتج" required></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>الفني المسؤول</label><input class="input-field" name="tech" placeholder="اسم الفني"></div>
        <div class="form-group"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>تاريخ التركيب</label><input class="input-field" type="date" name="start" required></div>
        <div class="form-group"><label>تاريخ الانتهاء</label><input class="input-field" type="date" name="end" required></div>
      </div>
      <button name="save" class="btn-gold" style="width:100%;padding:13px;font-size:15px"><i class="fa-solid fa-shield-halved"></i> إنشاء الضمان</button>
    </form>
  </div>
</div>
<script src="../assets/js/app.js"></script></body></html>
