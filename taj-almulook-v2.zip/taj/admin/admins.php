<?php
session_start();
if(!isset($_SESSION['user'])||$_SESSION['role']!='admin'){header("Location: ../login.php");exit;}
$admin_name=$_SESSION['name']??'المدير';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>المسؤولون | تاج الملوك</title>
</head><body>
<div class='admin-layout'>
<div class="admin-sidebar">
  <div class="admin-sidebar-logo">
    <img src="../assets/images/logo.png" alt="تاج الملوك">
    <h3>تاج الملوك</h3>
  </div>
  <nav class="admin-nav">
    <div class="nav-group">الرئيسية</div>
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <div class="nav-group">إدارة</div>
    <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>"><i class="fa-solid fa-users"></i> العملاء</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> السيارات</a>
    <a href="products.php" class="<?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>"><i class="fa-solid fa-box"></i> المنتجات</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> الحجوزات</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> الضمانات</a>
    <div class="nav-group">التقارير</div>
    <a href="reports.php" class="<?= basename($_SERVER['PHP_SELF'])=='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-bar"></i> التقارير</a>
    <a href="admins.php" class="<?= basename($_SERVER['PHP_SELF'])=='admins.php'?'active':'' ?>"><i class="fa-solid fa-user-shield"></i> المسؤولون</a>
    <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>"><i class="fa-solid fa-gear"></i> الإعدادات</a>
    <div class="nav-group">الحساب</div>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<?php
require_once("../database/config.php");
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_admin'])){
  $fn=mysqli_real_escape_string($conn,$_POST['fullname']);
  $em=mysqli_real_escape_string($conn,$_POST['email']);
  $ph=mysqli_real_escape_string($conn,$_POST['phone']);
  $rl=mysqli_real_escape_string($conn,$_POST['role']);
  $pw=password_hash($_POST['password'],PASSWORD_DEFAULT);
  $chk=mysqli_query($conn,"SELECT id FROM users WHERE email='$em'");
  if(mysqli_num_rows($chk)>0){$msg='<div style="background:rgba(224,0,36,.1);border:1px solid rgba(224,0,36,.3);color:#f87171;padding:12px;border-radius:8px;margin-bottom:16px">❌ البريد الإلكتروني مسجل مسبقاً</div>';}
  else{
    mysqli_query($conn,"INSERT INTO users(fullname,email,phone,password,role) VALUES('$fn','$em','$ph','$pw','$rl')");
    $msg='<div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;padding:12px;border-radius:8px;margin-bottom:16px">✅ تم إضافة المسؤول بنجاح</div>';
  }
}
$result=mysqli_query($conn,"SELECT * FROM users WHERE role IN('admin','employee') ORDER BY id DESC");
?>
<div class="admin-main">
  <div class="admin-topbar"><h1>إدارة <span>المسؤولين والموظفين</span></h1></div>
  <?= $msg ?>
  <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;align-items:start">
    <div class="form-card">
      <div class="form-title"><i class="fa-solid fa-user-plus"></i> إضافة مسؤول جديد</div>
      <form method="POST">
        <div class="form-group" style="margin-bottom:12px"><label style="font-size:12px;color:#888;display:block;margin-bottom:5px">الاسم الكامل</label><input class="input-field" type="text" name="fullname" placeholder="اسم المسؤول" required></div>
        <div class="form-group" style="margin-bottom:12px"><label style="font-size:12px;color:#888;display:block;margin-bottom:5px">البريد الإلكتروني</label><input class="input-field" type="email" name="email" placeholder="example@taj.com" required></div>
        <div class="form-group" style="margin-bottom:12px"><label style="font-size:12px;color:#888;display:block;margin-bottom:5px">رقم الجوال</label><input class="input-field" type="tel" name="phone" placeholder="7xxxxxxxx"></div>
        <div class="form-group" style="margin-bottom:12px"><label style="font-size:12px;color:#888;display:block;margin-bottom:5px">الصلاحية</label>
          <select class="input-field" name="role">
            <option value="admin">مدير</option>
            <option value="employee">موظف استقبال</option>
          </select>
        </div>
        <div class="form-group" style="margin-bottom:16px"><label style="font-size:12px;color:#888;display:block;margin-bottom:5px">كلمة المرور</label><input class="input-field" type="password" name="password" placeholder="••••••••" required></div>
        <button type="submit" name="add_admin" class="btn-gold" style="width:100%;padding:12px"><i class="fa-solid fa-user-plus"></i> إضافة المسؤول</button>
      </form>
    </div>
    <div class="table-card">
      <div style="font-size:15px;font-weight:800;color:var(--gold);margin-bottom:18px">قائمة المسؤولين والموظفين</div>
      <table class="data-table"><thead><tr><th>#</th><th>الاسم</th><th>البريد</th><th>الجوال</th><th>الصلاحية</th><th>الإجراءات</th></tr></thead>
      <tbody>
      <?php while($row=mysqli_fetch_assoc($result)): ?>
      <tr>
        <td><?=$row['id']?></td>
        <td><strong><?=htmlspecialchars($row['fullname'])?></strong></td>
        <td style="font-size:12px"><?=htmlspecialchars($row['email'])?></td>
        <td><?=$row['phone']?></td>
        <td><?php $rl=$row['role'];$labels=['admin'=>'مدير','employee'=>'موظف'];$colors=['admin'=>'badge-gold','employee'=>'badge-blue'];echo "<span class='badge ".($colors[$rl]??'badge-gray')."'>".($labels[$rl]??$rl)."</span>"; ?></td>
        <td>
          <?php if($row['id']!=1): ?>
          <a class="action-btn danger" href="?delete=<?=$row['id']?>" onclick="return confirm('حذف هذا المسؤول؟')"><i class="fa-solid fa-trash"></i></a>
          <?php else: ?>
          <span style="font-size:12px;color:#333">محمي</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endwhile; ?>
      </tbody></table>
    </div>
  </div>
</div>
</div>
<?php
if(isset($_GET['delete']) && $_GET['delete']!=1){
  $id=(int)$_GET['delete'];
  mysqli_query($conn,"DELETE FROM users WHERE id=$id AND id!=1");
  header("Location: admins.php");exit;
}
?>
<script src="../assets/js/app.js"></script></body></html>