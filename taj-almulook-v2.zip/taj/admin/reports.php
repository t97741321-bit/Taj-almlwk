<?php
session_start();
if(!isset($_SESSION['user'])||$_SESSION['role']!='admin'){header("Location: ../login.php");exit;}
$admin_name=$_SESSION['name']??'المدير';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>التقارير | تاج الملوك</title>
</head><body>
<div class='admin-layout'>
<div class="admin-sidebar">
  <div class="admin-sidebar-logo">
    <img src="../assets/images/logo.png" alt="تاج الملوك">
    <h3>تاج الملوك</h3>
  </div>
  <nav class="admin-nav">
    <div class="nav-group">الرئيسية</div>
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <div class="nav-group">إدارة</div>
    <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>"><i class="fa-solid fa-users"></i> العملاء</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> السيارات</a>
    <a href="products.php" class="<?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>"><i class="fa-solid fa-box"></i> المنتجات</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> الحجوزات</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> الضمانات</a>
    <div class="nav-group">التقارير</div>
    <a href="reports.php" class="<?= basename($_SERVER['PHP_SELF'])=='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-bar"></i> التقارير</a>
    <a href="admins.php" class="<?= basename($_SERVER['PHP_SELF'])=='admins.php'?'active':'' ?>"><i class="fa-solid fa-user-shield"></i> المسؤولون</a>
    <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>"><i class="fa-solid fa-gear"></i> الإعدادات</a>
    <div class="nav-group">الحساب</div>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<div class="admin-main">
  <div class="admin-topbar"><h1>📊 <span>التقارير والإحصائيات</span></h1>
    <div class="actions"><button class="btn-gold btn-sm" onclick="window.print()"><i class="fa-solid fa-print"></i> طباعة</button></div>
  </div>
  <div class="admin-stats">
    <div class="admin-stat-card"><span class="stat-icon">💰</span><label>المبيعات اليومية</label><h2>4,200</h2><p>ريال يمني</p></div>
    <div class="admin-stat-card"><span class="stat-icon">📅</span><label>المبيعات الشهرية</label><h2>85,000</h2><p>▲ 12% عن الشهر السابق</p></div>
    <div class="admin-stat-card"><span class="stat-icon">📦</span><label>الطلبات هذا الشهر</label><h2>87</h2><p>▲ 15 طلب جديد</p></div>
    <div class="admin-stat-card"><span class="stat-icon">🛡️</span><label>الضمانات النشطة</label><h2>3,854</h2><p></p></div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
    <div class="dash-card">
      <div class="dash-card-header"><h3>أكثر الخدمات طلباً</h3></div>
      <?php $services=[['PPF 3M',45],['شاشات Pioneer',32],['عازل حراري',28],['إضاءة LED',20],['كاميرات',15]];
      foreach($services as $s): $w=round(($s[1]/45)*100); ?>
      <div style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px"><span><?=$s[0]?></span><strong style="color:var(--gold)"><?=$s[1]?> طلب</strong></div>
        <div style="background:#1a1a1a;border-radius:4px;height:8px"><div style="background:linear-gradient(90deg,var(--gold),var(--gold2));height:8px;border-radius:4px;width:<?=$w?>%"></div></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="dash-card">
      <div class="dash-card-header"><h3>أكثر المنتجات مبيعاً</h3></div>
      <table class="data-table"><thead><tr><th>المنتج</th><th>الكمية</th><th>الإيراد</th></tr></thead>
      <tbody>
        <tr><td>PPF 3M كامل</td><td>23</td><td style="color:var(--gold)">46,000 ر.ي</td></tr>
        <tr><td>شاشة Pioneer</td><td>18</td><td style="color:var(--gold)">21,600 ر.ي</td></tr>
        <tr><td>عازل 3M</td><td>30</td><td style="color:var(--gold)">24,000 ر.ي</td></tr>
        <tr><td>سماعات Pioneer</td><td>42</td><td style="color:var(--gold)">11,760 ر.ي</td></tr>
      </tbody></table>
    </div>
  </div>
</div>
</div>
<script src="../assets/js/app.js"></script></body></html>