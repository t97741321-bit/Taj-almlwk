<?php
session_start();
if(!isset($_SESSION['user'])||$_SESSION['role']!='admin'){header("Location: ../login.php");exit;}
$admin_name=$_SESSION['name']??'المدير';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>العملاء | تاج الملوك</title>
</head><body>
<div class='admin-layout'>
<div class="admin-sidebar">
  <div class="admin-sidebar-logo">
    <img src="../assets/images/logo.png" alt="تاج الملوك">
    <h3>تاج الملوك</h3>
  </div>
  <nav class="admin-nav">
    <div class="nav-group">الرئيسية</div>
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <div class="nav-group">إدارة</div>
    <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>"><i class="fa-solid fa-users"></i> العملاء</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> السيارات</a>
    <a href="products.php" class="<?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>"><i class="fa-solid fa-box"></i> المنتجات</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> الحجوزات</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> الضمانات</a>
    <div class="nav-group">التقارير</div>
    <a href="reports.php" class="<?= basename($_SERVER['PHP_SELF'])=='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-bar"></i> التقارير</a>
    <a href="admins.php" class="<?= basename($_SERVER['PHP_SELF'])=='admins.php'?'active':'' ?>"><i class="fa-solid fa-user-shield"></i> المسؤولون</a>
    <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>"><i class="fa-solid fa-gear"></i> الإعدادات</a>
    <div class="nav-group">الحساب</div>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<?php require_once("../database/config.php");
$result=mysqli_query($conn,"SELECT * FROM users WHERE role='customer' ORDER BY id DESC"); ?>
<div class="admin-main">
  <div class="admin-topbar"><h1>إدارة <span>العملاء</span></h1>
    <div class="actions"><button class="btn-gold btn-sm" onclick="document.getElementById('addModal').classList.add('open')"><i class="fa-solid fa-plus"></i> إضافة عميل</button></div>
  </div>
  <div class="table-card">
    <div class="top-bar">
      <input class="search-box" type="text" placeholder="🔍 بحث..." onkeyup="searchTable('this','cTable')">
    </div>
    <table class="data-table" id="cTable"><thead><tr><th>#</th><th>الاسم</th><th>البريد</th><th>الجوال</th><th>تاريخ التسجيل</th><th>الإجراءات</th></tr></thead>
    <tbody>
    <?php while($row=mysqli_fetch_assoc($result)): ?>
    <tr>
      <td><?=$row['id']?></td><td><?=htmlspecialchars($row['fullname'])?></td>
      <td><?=htmlspecialchars($row['email'])?></td><td><?=htmlspecialchars($row['phone'])?></td>
      <td><?=$row['created_at']?></td>
      <td>
        <button class="action-btn"><i class="fa-solid fa-eye"></i></button>
        <button class="action-btn"><i class="fa-solid fa-pen"></i></button>
        <a class="action-btn danger" href="../api/delete_customer.php?id=<?=$row['id']?>" onclick="return confirm('حذف العميل؟')"><i class="fa-solid fa-trash"></i></a>
      </td>
    </tr>
    <?php endwhile; ?>
    </tbody></table>
  </div>
  <div class="modal-overlay" id="addModal">
    <div class="modal-box">
      <button class="modal-close" onclick="document.getElementById('addModal').classList.remove('open')">✕</button>
      <div class="modal-title">إضافة عميل جديد</div>
      <form action="../api/add_customer.php" method="POST">
        <input class="input-field" type="text" name="fullname" placeholder="الاسم الكامل" required>
        <input class="input-field" type="email" name="email" placeholder="البريد الإلكتروني" required>
        <input class="input-field" type="tel" name="phone" placeholder="رقم الجوال">
        <input class="input-field" type="password" name="password" placeholder="كلمة المرور" required>
        <button type="submit" class="btn-gold" style="width:100%;padding:12px">حفظ</button>
      </form>
    </div>
  </div>
</div>
</div>
<script src="../assets/js/app.js"></script></body></html>