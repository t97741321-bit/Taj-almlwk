<?php
session_start();
if(!isset($_SESSION['user'])||$_SESSION['role']!='admin'){header("Location: ../login.php");exit;}
$admin_name=$_SESSION['name']??'المدير';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>لوحة الإدارة | تاج الملوك</title>
</head><body>
<div class='admin-layout'>
<div class="admin-sidebar">
  <div class="admin-sidebar-logo">
    <img src="../assets/images/logo.png" alt="تاج الملوك">
    <h3>تاج الملوك</h3>
  </div>
  <nav class="admin-nav">
    <div class="nav-group">الرئيسية</div>
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <div class="nav-group">إدارة</div>
    <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>"><i class="fa-solid fa-users"></i> العملاء</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> السيارات</a>
    <a href="products.php" class="<?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>"><i class="fa-solid fa-box"></i> المنتجات</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> الحجوزات</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> الضمانات</a>
    <div class="nav-group">التقارير</div>
    <a href="reports.php" class="<?= basename($_SERVER['PHP_SELF'])=='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-bar"></i> التقارير</a>
    <a href="admins.php" class="<?= basename($_SERVER['PHP_SELF'])=='admins.php'?'active':'' ?>"><i class="fa-solid fa-user-shield"></i> المسؤولون</a>
    <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>"><i class="fa-solid fa-gear"></i> الإعدادات</a>
    <div class="nav-group">الحساب</div>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<div class="admin-main">
  <div class="admin-topbar">
    <h1>لوحة <span>التحكم</span></h1>
    <div class="actions">
      <span style="font-size:13px;color:var(--gray)">مرحباً، <?= htmlspecialchars($admin_name) ?> 👑</span>
      <a href="../index.html" class="btn-outline btn-sm">الموقع</a>
    </div>
  </div>
  <div class="admin-stats">
    <div class="admin-stat-card"><span class="stat-icon">👥</span><label>العملاء</label><h2>1,248</h2><p>▲ 8 جدد اليوم</p></div>
    <div class="admin-stat-card"><span class="stat-icon">🚗</span><label>السيارات</label><h2>2,356</h2><p>▲ 3 جديدة</p></div>
    <div class="admin-stat-card"><span class="stat-icon">📅</span><label>الحجوزات اليوم</label><h2>14</h2><p>▲ 3 جديدة</p></div>
    <div class="admin-stat-card"><span class="stat-icon">📦</span><label>الطلبات</label><h2>87</h2><p>▲ هذا الشهر</p></div>
    <div class="admin-stat-card"><span class="stat-icon">🛡️</span><label>الضمانات</label><h2>3,854</h2><p>▲ 23 هذا الأسبوع</p></div>
    <div class="admin-stat-card"><span class="stat-icon">💰</span><label>المبيعات اليوم</label><h2>4,200</h2><p>ريال يمني</p></div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
    <div class="dash-card">
      <div class="dash-card-header"><h3>آخر الحجوزات</h3><a href="bookings.php">عرض الكل</a></div>
      <table class="data-table"><thead><tr><th>العميل</th><th>الخدمة</th><th>التاريخ</th><th>الحالة</th></tr></thead>
      <tbody>
        <tr><td>محمد العمري</td><td>تركيب Pioneer</td><td>اليوم 10:00</td><td><span class="badge badge-blue">جارٍ</span></td></tr>
        <tr><td>خالد الشمري</td><td>حماية 3M</td><td>اليوم 1:00م</td><td><span class="badge badge-gold">قادم</span></td></tr>
        <tr><td>سارة الحربي</td><td>إضاءة LED</td><td>أمس</td><td><span class="badge badge-green">مكتمل</span></td></tr>
        <tr><td>فيصل القحطاني</td><td>نظام صوتي</td><td>أمس</td><td><span class="badge badge-green">مكتمل</span></td></tr>
      </tbody></table>
    </div>
    <div class="dash-card">
      <div class="dash-card-header"><h3>آخر العملاء</h3><a href="customers.php">عرض الكل</a></div>
      <table class="data-table"><thead><tr><th>الاسم</th><th>الجوال</th><th>التاريخ</th></tr></thead>
      <tbody>
        <tr><td>محمد العمري</td><td>0501234567</td><td>اليوم</td></tr>
        <tr><td>خالد الشمري</td><td>0509876543</td><td>أمس</td></tr>
        <tr><td>سارة الحربي</td><td>0551234567</td><td>2024-04-01</td></tr>
        <tr><td>نورة السبيعي</td><td>0561234567</td><td>2024-03-28</td></tr>
      </tbody></table>
    </div>
  </div>
  <div class="dash-card">
    <div class="dash-card-header"><h3>📊 المبيعات الشهرية</h3></div>
    <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin-top:10px">
      <?php $months=['يناير'=>12000,'فبراير'=>18000,'مارس'=>15000,'أبريل'=>22000,'مايو'=>19000,'يونيو'=>25000];
      $max=max($months);
      foreach($months as $m=>$v): $h=round(($v/$max)*180); ?>
      <div style="text-align:center">
        <div style="height:200px;display:flex;align-items:flex-end;justify-content:center">
          <div style="width:40px;height:<?=$h?>px;background:linear-gradient(to top,var(--gold),var(--gold2));border-radius:4px 4px 0 0"></div>
        </div>
        <div style="font-size:11px;color:var(--gray);margin-top:6px"><?=$m?></div>
        <div style="font-size:12px;color:var(--gold);font-weight:700"><?=number_format($v)?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
</div>
<script src="../assets/js/app.js"></script></body></html>