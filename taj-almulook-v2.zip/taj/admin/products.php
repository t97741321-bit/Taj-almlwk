<?php
session_start();
if(!isset($_SESSION['user'])||$_SESSION['role']!='admin'){header("Location: ../login.php");exit;}
$admin_name=$_SESSION['name']??'المدير';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>المنتجات | تاج الملوك</title>
</head><body>
<div class='admin-layout'>
<div class="admin-sidebar">
  <div class="admin-sidebar-logo">
    <img src="../assets/images/logo.png" alt="تاج الملوك">
    <h3>تاج الملوك</h3>
  </div>
  <nav class="admin-nav">
    <div class="nav-group">الرئيسية</div>
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <div class="nav-group">إدارة</div>
    <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>"><i class="fa-solid fa-users"></i> العملاء</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> السيارات</a>
    <a href="products.php" class="<?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>"><i class="fa-solid fa-box"></i> المنتجات</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> الحجوزات</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> الضمانات</a>
    <div class="nav-group">التقارير</div>
    <a href="reports.php" class="<?= basename($_SERVER['PHP_SELF'])=='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-bar"></i> التقارير</a>
    <a href="admins.php" class="<?= basename($_SERVER['PHP_SELF'])=='admins.php'?'active':'' ?>"><i class="fa-solid fa-user-shield"></i> المسؤولون</a>
    <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>"><i class="fa-solid fa-gear"></i> الإعدادات</a>
    <div class="nav-group">الحساب</div>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<?php require_once("../database/config.php");
$result=mysqli_query($conn,"SELECT * FROM products ORDER BY id DESC"); ?>
<div class="admin-main">
  <div class="admin-topbar"><h1>إدارة <span>المنتجات</span></h1>
    <div class="actions"><button class="btn-gold btn-sm" onclick="document.getElementById('addProd').classList.add('open')"><i class="fa-solid fa-plus"></i> إضافة منتج</button></div>
  </div>
  <div class="table-card">
    <table class="data-table"><thead><tr><th>#</th><th>اسم المنتج</th><th>الماركة</th><th>السعر</th><th>المخزون</th><th>الفئة</th><th>الإجراءات</th></tr></thead>
    <tbody>
    <?php while($row=mysqli_fetch_assoc($result)): ?>
    <tr>
      <td><?=$row['id']?></td><td><?=htmlspecialchars($row['name'])?></td>
      <td><?=htmlspecialchars($row['brand'])?></td>
      <td style="color:var(--gold);font-weight:700"><?=number_format($row['price'])?> ر.ي</td>
      <td><?php $s=$row['stock'];echo "<span class='badge ".($s>5?'badge-green':($s>0?'badge-gold':'badge-red'))."'>$s</span>"; ?></td>
      <td><?=$row['category_id']?></td>
      <td>
        <button class="action-btn"><i class="fa-solid fa-pen"></i></button>
        <button class="action-btn danger"><i class="fa-solid fa-trash"></i></button>
      </td>
    </tr>
    <?php endwhile; ?>
    </tbody></table>
  </div>
  <div class="modal-overlay" id="addProd">
    <div class="modal-box" style="max-width:600px">
      <button class="modal-close" onclick="document.getElementById('addProd').classList.remove('open')">✕</button>
      <div class="modal-title">إضافة منتج جديد</div>
      <form action="../api/add_product.php" method="POST" enctype="multipart/form-data">
        <div class="form-row"><div class="form-group"><label>اسم المنتج</label><input class="input-field" type="text" name="name" required></div><div class="form-group"><label>الماركة</label><input class="input-field" type="text" name="brand"></div></div>
        <div class="form-row"><div class="form-group"><label>السعر</label><input class="input-field" type="number" name="price" required></div><div class="form-group"><label>السعر القديم</label><input class="input-field" type="number" name="old_price"></div></div>
        <div class="form-row"><div class="form-group"><label>المخزون</label><input class="input-field" type="number" name="stock" value="1"></div><div class="form-group"><label>الفئة</label><select class="input-field" name="category_id"><option value="1">شاشات</option><option value="2">سماعات</option><option value="3">كاميرات</option><option value="4">عازل حراري</option><option value="5">أفلام الحماية</option><option value="6">إكسسوارات</option><option value="7">إضاءة</option></select></div></div>
        <textarea class="input-field" name="description" placeholder="وصف المنتج" style="height:80px;resize:none"></textarea>
        <label style="font-size:13px;color:#999;margin-bottom:6px;display:block">صور المنتج (يمكن تحميل أكثر من صورة)</label>
        <input class="input-field" type="file" name="images[]" multiple accept="image/*">
        <button type="submit" class="btn-gold" style="width:100%;padding:12px;margin-top:8px">حفظ المنتج</button>
      </form>
    </div>
  </div>
</div>
</div>
<script src="../assets/js/app.js"></script></body></html>