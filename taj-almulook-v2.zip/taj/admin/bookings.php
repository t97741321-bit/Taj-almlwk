<?php
session_start();
if(!isset($_SESSION['user'])||$_SESSION['role']!='admin'){header("Location: ../login.php");exit;}
$admin_name=$_SESSION['name']??'المدير';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>الحجوزات | تاج الملوك</title>
</head><body>
<div class='admin-layout'>
<div class="admin-sidebar">
  <div class="admin-sidebar-logo">
    <img src="../assets/images/logo.png" alt="تاج الملوك">
    <h3>تاج الملوك</h3>
  </div>
  <nav class="admin-nav">
    <div class="nav-group">الرئيسية</div>
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <div class="nav-group">إدارة</div>
    <a href="customers.php" class="<?= basename($_SERVER['PHP_SELF'])=='customers.php'?'active':'' ?>"><i class="fa-solid fa-users"></i> العملاء</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> السيارات</a>
    <a href="products.php" class="<?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>"><i class="fa-solid fa-box"></i> المنتجات</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> الحجوزات</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> الضمانات</a>
    <div class="nav-group">التقارير</div>
    <a href="reports.php" class="<?= basename($_SERVER['PHP_SELF'])=='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-bar"></i> التقارير</a>
    <a href="admins.php" class="<?= basename($_SERVER['PHP_SELF'])=='admins.php'?'active':'' ?>"><i class="fa-solid fa-user-shield"></i> المسؤولون</a>
    <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>"><i class="fa-solid fa-gear"></i> الإعدادات</a>
    <div class="nav-group">الحساب</div>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<?php require_once("../database/config.php");
$result=mysqli_query($conn,"SELECT b.*,u.fullname,s.title FROM bookings b LEFT JOIN users u ON b.user_id=u.id LEFT JOIN services s ON b.service_id=s.id ORDER BY b.id DESC"); ?>
<div class="admin-main">
  <div class="admin-topbar"><h1>إدارة <span>الحجوزات</span></h1></div>
  <div class="table-card">
    <table class="data-table"><thead><tr><th>#</th><th>العميل</th><th>الخدمة</th><th>التاريخ</th><th>الوقت</th><th>الحالة</th><th>الإجراءات</th></tr></thead>
    <tbody>
    <?php while($row=mysqli_fetch_assoc($result)): ?>
    <tr>
      <td><?=$row['id']?></td>
      <td><?=htmlspecialchars($row['fullname']??'—')?></td>
      <td><?=htmlspecialchars($row['title']??$row['service_id'])?></td>
      <td><?=$row['booking_date']?></td>
      <td><?=$row['booking_time']?></td>
      <td><?php $s=$row['status'];$cl=['pending'=>'badge-gold','confirmed'=>'badge-blue','done'=>'badge-green','cancelled'=>'badge-red'];$lb=['pending'=>'قيد الانتظار','confirmed'=>'مؤكد','done'=>'مكتمل','cancelled'=>'ملغي'];echo "<span class='badge ".($cl[$s]??'badge-gray')."'>".($lb[$s]??$s)."</span>"; ?></td>
      <td>
        <a class="action-btn" href="?confirm=<?=$row['id']?>"><i class="fa-solid fa-check"></i></a>
        <a class="action-btn danger" href="?cancel=<?=$row['id']?>"><i class="fa-solid fa-xmark"></i></a>
      </td>
    </tr>
    <?php endwhile; ?>
    </tbody></table>
  </div>
</div>
</div>
<script src="../assets/js/app.js"></script></body></html>