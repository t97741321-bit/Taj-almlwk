<?php session_start(); $err=isset($_GET['error'])?$_GET['error']:''; ?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>إنشاء حساب | تاج الملوك</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
</head><body>
<div class="auth-page">
<div class="auth-card">
  <div class="auth-logo"><img src="assets/images/logo.png" alt="تاج الملوك"><h2>إنشاء حساب جديد</h2><p>انضم إلى عائلة تاج الملوك</p></div>
  <?php if($err=='exists'): ?><div style="background:rgba(224,0,36,.1);border:1px solid rgba(224,0,36,.3);color:#f87171;padding:12px;border-radius:8px;margin-bottom:18px;font-size:13px;text-align:center">❌ البريد الإلكتروني مسجل مسبقاً</div><?php endif; ?>
  <form class="auth-form" action="api/register.php" method="POST">
    <div class="form-group"><label>الاسم الكامل</label><input type="text" name="fullname" placeholder="محمد أحمد العمري" required></div>
    <div class="form-group"><label>البريد الإلكتروني</label><input type="email" name="email" placeholder="example@email.com" required></div>
    <div class="form-group"><label>رقم الجوال</label><input type="tel" name="phone" placeholder="7xxxxxxxx" required></div>
    <div class="form-group"><label>كلمة المرور</label><input type="password" name="password" placeholder="••••••••" required></div>
    <button type="submit" class="btn-gold" style="width:100%;padding:13px;font-size:15px;margin-top:6px"><i class="fa-solid fa-user-plus"></i> إنشاء الحساب</button>
  </form>
  <div class="auth-footer">لديك حساب؟ <a href="login.php">تسجيل الدخول</a></div>
</div>
</div>
<script src="assets/js/app.js"></script>
</body></html>