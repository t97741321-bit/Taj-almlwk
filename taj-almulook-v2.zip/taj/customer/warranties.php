<?php
session_start();
if(!isset($_SESSION['user'])){header("Location: ../login.php");exit;}
$name = $_SESSION['name'] ?? 'العميل';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>ضماناتي | تاج الملوك</title>
</head><body>
<div class="customer-sidebar">
  <div class="sidebar-user">
    <div class="avatar"><?= mb_substr($name,0,1) ?></div>
    <h4><?= htmlspecialchars($name) ?></h4>
    <p>عميل مميز ⭐</p>
  </div>
  <div class="sidebar-group-label">القائمة</div>
  <nav class="sidebar-nav">
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> سياراتي</a>
    <a href="orders.php" class="<?= basename($_SERVER['PHP_SELF'])=='orders.php'?'active':'' ?>"><i class="fa-solid fa-bag-shopping"></i> طلباتي</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> ضماناتي</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> حجوزاتي</a>
    <a href="profile.php" class="<?= basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'' ?>"><i class="fa-solid fa-user"></i> ملفي الشخصي</a>
    <div class="sidebar-group-label">أخرى</div>
    <a href="../shop.html"><i class="fa-solid fa-store"></i> المتجر</a>
    <a href="../booking.html"><i class="fa-solid fa-calendar-plus"></i> حجز جديد</a>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<div class="customer-main">
  <div class="page-header"><h1>🛡️ <span>ضماناتي الرقمية</span></h1><p>جميع ضماناتك في مكان واحد</p></div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px">
    <div class="dash-card" style="border-color:rgba(34,197,94,.3)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
        <h3 style="color:var(--gold)">TM001</h3><span class="badge badge-green">✅ ساري</span>
      </div>
      <div style="font-size:13px;display:grid;gap:8px">
        <div style="display:flex;justify-content:space-between"><span style="color:#555">المنتج:</span><strong>فيلم حماية PPF 3M</strong></div>
        <div style="display:flex;justify-content:space-between"><span style="color:#555">الخدمة:</span><strong>تركيب PPF كامل</strong></div>
        <div style="display:flex;justify-content:space-between"><span style="color:#555">تاريخ التركيب:</span><strong>2024-01-15</strong></div>
        <div style="display:flex;justify-content:space-between"><span style="color:#555">ينتهي في:</span><strong style="color:#4ade80">2026-01-15</strong></div>
        <div style="display:flex;justify-content:space-between"><span style="color:#555">الفني:</span><strong>فيصل الغامدي</strong></div>
      </div>
      <div style="margin-top:16px;background:#111;border-radius:8px;padding:12px;text-align:center;font-size:12px;color:#555">
        <i class="fa-solid fa-qrcode" style="font-size:40px;color:var(--gold);display:block;margin-bottom:6px"></i>
        امسح QR للتحقق
      </div>
    </div>
    <div class="dash-card" style="border-color:rgba(212,175,55,.3)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
        <h3 style="color:var(--gold)">TM002</h3><span class="badge badge-gold">✅ ساري</span>
      </div>
      <div style="font-size:13px;display:grid;gap:8px">
        <div style="display:flex;justify-content:space-between"><span style="color:#555">المنتج:</span><strong>Pioneer DMH-9600</strong></div>
        <div style="display:flex;justify-content:space-between"><span style="color:#555">الخدمة:</span><strong>تركيب شاشة أندرويد</strong></div>
        <div style="display:flex;justify-content:space-between"><span style="color:#555">تاريخ التركيب:</span><strong>2024-03-10</strong></div>
        <div style="display:flex;justify-content:space-between"><span style="color:#555">ينتهي في:</span><strong style="color:var(--gold)">2025-03-10</strong></div>
        <div style="display:flex;justify-content:space-between"><span style="color:#555">الفني:</span><strong>محمد الزهراني</strong></div>
      </div>
      <div style="margin-top:16px;background:#111;border-radius:8px;padding:12px;text-align:center;font-size:12px;color:#555">
        <i class="fa-solid fa-qrcode" style="font-size:40px;color:var(--gold);display:block;margin-bottom:6px"></i>
        امسح QR للتحقق
      </div>
    </div>
  </div>
  <div style="margin-top:24px;text-align:center">
    <a href="../warranty.html" class="btn-outline"><i class="fa-solid fa-magnifying-glass"></i> التحقق من ضمان</a>
  </div>
</div>
<script src="../assets/js/app.js"></script></body></html>