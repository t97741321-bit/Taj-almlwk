<?php
session_start();
if(!isset($_SESSION['user'])){header("Location: ../login.php");exit;}
$name = $_SESSION['name'] ?? 'العميل';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>لوحة العميل | تاج الملوك</title>
</head><body>
<div class="customer-sidebar">
  <div class="sidebar-user">
    <div class="avatar"><?= mb_substr($name,0,1) ?></div>
    <h4><?= htmlspecialchars($name) ?></h4>
    <p>عميل مميز ⭐</p>
  </div>
  <div class="sidebar-group-label">القائمة</div>
  <nav class="sidebar-nav">
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> سياراتي</a>
    <a href="orders.php" class="<?= basename($_SERVER['PHP_SELF'])=='orders.php'?'active':'' ?>"><i class="fa-solid fa-bag-shopping"></i> طلباتي</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> ضماناتي</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> حجوزاتي</a>
    <a href="profile.php" class="<?= basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'' ?>"><i class="fa-solid fa-user"></i> ملفي الشخصي</a>
    <div class="sidebar-group-label">أخرى</div>
    <a href="../shop.html"><i class="fa-solid fa-store"></i> المتجر</a>
    <a href="../booking.html"><i class="fa-solid fa-calendar-plus"></i> حجز جديد</a>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<div class="customer-main">
  <div class="page-header"><h1>مرحباً، <span><?= htmlspecialchars($name) ?> 👋</span></h1><p>مرحباً بك في لوحة تحكمك الشخصية</p></div>
  <div class="kpi-grid">
    <div class="kpi-card"><span class="kpi-icon">🚗</span><div class="kpi-label">سياراتي</div><div class="kpi-value">3</div></div>
    <div class="kpi-card"><span class="kpi-icon">📦</span><div class="kpi-label">طلباتي</div><div class="kpi-value">7</div></div>
    <div class="kpi-card"><span class="kpi-icon">🛡️</span><div class="kpi-label">الضمانات</div><div class="kpi-value">5</div></div>
    <div class="kpi-card"><span class="kpi-icon">📅</span><div class="kpi-label">الحجوزات</div><div class="kpi-value">2</div></div>
    <div class="kpi-card"><span class="kpi-icon">⭐</span><div class="kpi-label">نقاط الولاء</div><div class="kpi-value">1,240</div></div>
  </div>
  <div class="dash-card">
    <div class="dash-card-header"><h3>آخر الطلبات</h3><a href="orders.php">عرض الكل</a></div>
    <table class="data-table"><thead><tr><th>#</th><th>الخدمة</th><th>التاريخ</th><th>المبلغ</th><th>الحالة</th></tr></thead>
    <tbody>
      <tr><td>1</td><td>تركيب PPF كامل</td><td>2024-03-15</td><td>2,000 ر.ي</td><td><span class="badge badge-green">مكتمل</span></td></tr>
      <tr><td>2</td><td>شاشة Pioneer</td><td>2024-02-10</td><td>1,200 ر.ي</td><td><span class="badge badge-green">مكتمل</span></td></tr>
      <tr><td>3</td><td>عازل حراري 3M</td><td>2024-04-01</td><td>800 ر.ي</td><td><span class="badge badge-gold">قيد التنفيذ</span></td></tr>
    </tbody></table>
  </div>
  <div class="dash-card">
    <div class="dash-card-header"><h3>آخر الفواتير</h3><a href="orders.php">عرض الكل</a></div>
    <table class="data-table"><thead><tr><th>#</th><th>رقم الفاتورة</th><th>التاريخ</th><th>المبلغ</th><th>الحالة</th></tr></thead>
    <tbody>
      <tr><td>1</td><td>INV-2024-001</td><td>2024-03-15</td><td>2,000 ر.ي</td><td><span class="badge badge-green">مدفوع</span></td></tr>
      <tr><td>2</td><td>INV-2024-002</td><td>2024-02-10</td><td>1,200 ر.ي</td><td><span class="badge badge-green">مدفوع</span></td></tr>
    </tbody></table>
  </div>
</div>
<script src="../assets/js/app.js"></script></body></html>