<?php
session_start();
if(!isset($_SESSION['user'])){header("Location: ../login.php");exit;}
$name = $_SESSION['name'] ?? 'العميل';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>طلباتي | تاج الملوك</title>
</head><body>
<div class="customer-sidebar">
  <div class="sidebar-user">
    <div class="avatar"><?= mb_substr($name,0,1) ?></div>
    <h4><?= htmlspecialchars($name) ?></h4>
    <p>عميل مميز ⭐</p>
  </div>
  <div class="sidebar-group-label">القائمة</div>
  <nav class="sidebar-nav">
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> سياراتي</a>
    <a href="orders.php" class="<?= basename($_SERVER['PHP_SELF'])=='orders.php'?'active':'' ?>"><i class="fa-solid fa-bag-shopping"></i> طلباتي</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> ضماناتي</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> حجوزاتي</a>
    <a href="profile.php" class="<?= basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'' ?>"><i class="fa-solid fa-user"></i> ملفي الشخصي</a>
    <div class="sidebar-group-label">أخرى</div>
    <a href="../shop.html"><i class="fa-solid fa-store"></i> المتجر</a>
    <a href="../booking.html"><i class="fa-solid fa-calendar-plus"></i> حجز جديد</a>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<div class="customer-main">
  <div class="page-header"><h1>📦 <span>طلباتي</span></h1><p>جميع طلباتك ومشترياتك</p></div>
  <div class="dash-card">
    <div class="dash-card-header"><h3>سجل الطلبات</h3></div>
    <table class="data-table"><thead><tr><th>#</th><th>رقم الطلب</th><th>المنتج/الخدمة</th><th>التاريخ</th><th>المبلغ</th><th>طريقة الدفع</th><th>الحالة</th><th>الفاتورة</th></tr></thead>
    <tbody>
      <tr><td>1</td><td>ORD-001</td><td>فيلم حماية PPF 3M</td><td>2024-03-15</td><td>2,000 ر.ي</td><td>بطاقة</td><td><span class="badge badge-green">مكتمل</span></td><td><button class="action-btn"><i class="fa-solid fa-file-pdf"></i> PDF</button></td></tr>
      <tr><td>2</td><td>ORD-002</td><td>شاشة Pioneer DMH-9600</td><td>2024-02-10</td><td>1,200 ر.ي</td><td>نقداً</td><td><span class="badge badge-green">مكتمل</span></td><td><button class="action-btn"><i class="fa-solid fa-file-pdf"></i> PDF</button></td></tr>
      <tr><td>3</td><td>ORD-003</td><td>عازل حراري 3M Ceramic</td><td>2024-04-01</td><td>800 ر.ي</td><td>STC Pay</td><td><span class="badge badge-gold">قيد التنفيذ</span></td><td><button class="action-btn" disabled>-</button></td></tr>
      <tr><td>4</td><td>ORD-004</td><td>سماعات Pioneer TS-A6960F</td><td>2024-01-20</td><td>280 ر.ي</td><td>تحويل</td><td><span class="badge badge-green">مكتمل</span></td><td><button class="action-btn"><i class="fa-solid fa-file-pdf"></i> PDF</button></td></tr>
    </tbody></table>
  </div>
</div>
<script src="../assets/js/app.js"></script></body></html>