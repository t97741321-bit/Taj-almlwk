<?php
session_start();
if(!isset($_SESSION['user'])){header("Location: ../login.php");exit;}
$name = $_SESSION['name'] ?? 'العميل';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>ملفي الشخصي | تاج الملوك</title>
</head><body>
<div class="customer-sidebar">
  <div class="sidebar-user">
    <div class="avatar"><?= mb_substr($name,0,1) ?></div>
    <h4><?= htmlspecialchars($name) ?></h4>
    <p>عميل مميز ⭐</p>
  </div>
  <div class="sidebar-group-label">القائمة</div>
  <nav class="sidebar-nav">
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> سياراتي</a>
    <a href="orders.php" class="<?= basename($_SERVER['PHP_SELF'])=='orders.php'?'active':'' ?>"><i class="fa-solid fa-bag-shopping"></i> طلباتي</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> ضماناتي</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> حجوزاتي</a>
    <a href="profile.php" class="<?= basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'' ?>"><i class="fa-solid fa-user"></i> ملفي الشخصي</a>
    <div class="sidebar-group-label">أخرى</div>
    <a href="../shop.html"><i class="fa-solid fa-store"></i> المتجر</a>
    <a href="../booking.html"><i class="fa-solid fa-calendar-plus"></i> حجز جديد</a>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<div class="customer-main">
  <div class="page-header"><h1>👤 <span>ملفي الشخصي</span></h1></div>
  <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:24px;align-items:start">
    <div class="dash-card" style="text-align:center">
      <div style="width:90px;height:90px;border-radius:50%;background:linear-gradient(135deg,var(--gold),var(--gold2));display:flex;align-items:center;justify-content:center;font-size:36px;font-weight:900;color:#000;margin:0 auto 16px"><?= mb_substr($name,0,1) ?></div>
      <h3 style="color:var(--gold)"><?= htmlspecialchars($name) ?></h3>
      <p style="color:var(--gray);font-size:13px;margin-top:4px">عميل مميز</p>
      <div style="margin-top:16px;background:#111;border-radius:8px;padding:12px;font-size:13px">
        <div style="color:#555;margin-bottom:4px">نقاط الولاء</div>
        <div style="font-size:24px;font-weight:900;color:var(--gold)">1,240 نقطة</div>
      </div>
    </div>
    <div class="form-card">
      <div class="form-title">تعديل البيانات الشخصية</div>
      <form action="../api/update_profile.php" method="POST">
        <div class="form-row">
          <div class="form-group"><label>الاسم الكامل</label><input class="input-field" type="text" name="fullname" value="<?= htmlspecialchars($name) ?>"></div>
          <div class="form-group"><label>رقم الجوال</label><input class="input-field" type="tel" name="phone" placeholder="7xxxxxxxx"></div>
        </div>
        <div class="form-group full"><label>البريد الإلكتروني</label><input class="input-field" type="email" name="email" placeholder="example@email.com"></div>
        <button type="submit" class="btn-gold" style="padding:12px 28px"><i class="fa-solid fa-save"></i> حفظ التغييرات</button>
      </form>
      <div style="margin-top:24px;border-top:1px solid var(--border);padding-top:20px">
        <div class="form-title">تغيير كلمة المرور</div>
        <input class="input-field" type="password" placeholder="كلمة المرور الحالية">
        <input class="input-field" type="password" placeholder="كلمة المرور الجديدة">
        <input class="input-field" type="password" placeholder="تأكيد كلمة المرور">
        <button class="btn-outline" style="padding:11px 24px"><i class="fa-solid fa-lock"></i> تغيير كلمة المرور</button>
      </div>
    </div>
  </div>
</div>
<script src="../assets/js/app.js"></script></body></html>