<?php
session_start();
if(!isset($_SESSION['user'])){header("Location: ../login.php");exit;}
$name = $_SESSION['name'] ?? 'العميل';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>سياراتي | تاج الملوك</title>
</head><body>
<div class="customer-sidebar">
  <div class="sidebar-user">
    <div class="avatar"><?= mb_substr($name,0,1) ?></div>
    <h4><?= htmlspecialchars($name) ?></h4>
    <p>عميل مميز ⭐</p>
  </div>
  <div class="sidebar-group-label">القائمة</div>
  <nav class="sidebar-nav">
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> سياراتي</a>
    <a href="orders.php" class="<?= basename($_SERVER['PHP_SELF'])=='orders.php'?'active':'' ?>"><i class="fa-solid fa-bag-shopping"></i> طلباتي</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> ضماناتي</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> حجوزاتي</a>
    <a href="profile.php" class="<?= basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'' ?>"><i class="fa-solid fa-user"></i> ملفي الشخصي</a>
    <div class="sidebar-group-label">أخرى</div>
    <a href="../shop.html"><i class="fa-solid fa-store"></i> المتجر</a>
    <a href="../booking.html"><i class="fa-solid fa-calendar-plus"></i> حجز جديد</a>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<div class="customer-main">
  <div class="page-header"><h1>🚗 <span>سياراتي</span></h1><p>إدارة سياراتك المسجلة</p></div>
  <div style="margin-bottom:20px"><button class="btn-gold btn-sm" onclick="document.getElementById('addCarModal').classList.add('open')"><i class="fa-solid fa-plus"></i> إضافة سيارة</button></div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px">
    <div class="dash-card" style="border-color:rgba(212,175,55,.3)">
      <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px">
        <div style="font-size:48px">🚗</div>
        <div><h3 style="color:var(--gold);font-size:18px">تويوتا كامري</h3><p style="color:var(--gray);font-size:13px">موديل 2023 • أبيض</p></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px">
        <div style="background:#111;padding:10px;border-radius:8px"><div style="color:#555;font-size:11px">رقم اللوحة</div><strong>أ ب ج 1234</strong></div>
        <div style="background:#111;padding:10px;border-radius:8px"><div style="color:#555;font-size:11px">رقم الهيكل</div><strong style="font-size:11px">JT2BF22K...</strong></div>
      </div>
      <div style="margin-top:14px;display:flex;gap:8px">
        <button class="action-btn"><i class="fa-solid fa-shield-halved"></i> الضمانات</button>
        <button class="action-btn"><i class="fa-solid fa-clock-rotate-left"></i> السجل</button>
        <button class="action-btn danger"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>
    <div class="dash-card">
      <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px">
        <div style="font-size:48px">🚙</div>
        <div><h3 style="color:var(--gold);font-size:18px">لكزس ES350</h3><p style="color:var(--gray);font-size:13px">موديل 2022 • أسود</p></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px">
        <div style="background:#111;padding:10px;border-radius:8px"><div style="color:#555;font-size:11px">رقم اللوحة</div><strong>د هـ و 5678</strong></div>
        <div style="background:#111;padding:10px;border-radius:8px"><div style="color:#555;font-size:11px">اللون</div><strong>أسود</strong></div>
      </div>
      <div style="margin-top:14px;display:flex;gap:8px">
        <button class="action-btn"><i class="fa-solid fa-shield-halved"></i> الضمانات</button>
        <button class="action-btn"><i class="fa-solid fa-clock-rotate-left"></i> السجل</button>
        <button class="action-btn danger"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>
  </div>
  <!-- ADD CAR MODAL -->
  <div class="modal-overlay" id="addCarModal">
    <div class="modal-box">
      <button class="modal-close" onclick="document.getElementById('addCarModal').classList.remove('open')">✕</button>
      <div class="modal-title">🚗 إضافة سيارة جديدة</div>
      <form action="../api/add_car.php" method="POST">
        <div class="form-row">
          <div class="form-group"><label>الماركة</label><input class="input-field" type="text" name="brand" placeholder="تويوتا" required></div>
          <div class="form-group"><label>الموديل</label><input class="input-field" type="text" name="model" placeholder="كامري" required></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>سنة الصنع</label><input class="input-field" type="text" name="year" placeholder="2023"></div>
          <div class="form-group"><label>اللون</label><input class="input-field" type="text" name="color" placeholder="أبيض"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>رقم اللوحة</label><input class="input-field" type="text" name="plate" placeholder="أ ب ج 1234"></div>
          <div class="form-group"><label>رقم الهيكل VIN</label><input class="input-field" type="text" name="vin" placeholder="JT2BF22K..."></div>
        </div>
        <button type="submit" class="btn-gold" style="width:100%;padding:12px">حفظ السيارة</button>
      </form>
    </div>
  </div>
</div>
<script src="../assets/js/app.js"></script></body></html>