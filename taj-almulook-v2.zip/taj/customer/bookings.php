<?php
session_start();
if(!isset($_SESSION['user'])){header("Location: ../login.php");exit;}
$name = $_SESSION['name'] ?? 'العميل';
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<title>حجوزاتي | تاج الملوك</title>
</head><body>
<div class="customer-sidebar">
  <div class="sidebar-user">
    <div class="avatar"><?= mb_substr($name,0,1) ?></div>
    <h4><?= htmlspecialchars($name) ?></h4>
    <p>عميل مميز ⭐</p>
  </div>
  <div class="sidebar-group-label">القائمة</div>
  <nav class="sidebar-nav">
    <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
    <a href="cars.php" class="<?= basename($_SERVER['PHP_SELF'])=='cars.php'?'active':'' ?>"><i class="fa-solid fa-car"></i> سياراتي</a>
    <a href="orders.php" class="<?= basename($_SERVER['PHP_SELF'])=='orders.php'?'active':'' ?>"><i class="fa-solid fa-bag-shopping"></i> طلباتي</a>
    <a href="warranties.php" class="<?= basename($_SERVER['PHP_SELF'])=='warranties.php'?'active':'' ?>"><i class="fa-solid fa-shield-halved"></i> ضماناتي</a>
    <a href="bookings.php" class="<?= basename($_SERVER['PHP_SELF'])=='bookings.php'?'active':'' ?>"><i class="fa-solid fa-calendar-check"></i> حجوزاتي</a>
    <a href="profile.php" class="<?= basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'' ?>"><i class="fa-solid fa-user"></i> ملفي الشخصي</a>
    <div class="sidebar-group-label">أخرى</div>
    <a href="../shop.html"><i class="fa-solid fa-store"></i> المتجر</a>
    <a href="../booking.html"><i class="fa-solid fa-calendar-plus"></i> حجز جديد</a>
    <a href="../api/logout.php" style="color:#f87171"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</a>
  </nav>
</div>
<div class="customer-main">
  <div class="page-header"><h1>📅 <span>حجوزاتي</span></h1><p>مواعيدك وحجوزاتك</p></div>
  <div style="margin-bottom:20px"><a href="../booking.html" class="btn-gold btn-sm"><i class="fa-solid fa-plus"></i> حجز جديد</a></div>
  <div class="dash-card">
    <table class="data-table"><thead><tr><th>#</th><th>الخدمة</th><th>السيارة</th><th>التاريخ</th><th>الوقت</th><th>الحالة</th></tr></thead>
    <tbody>
      <tr><td>1</td><td>تركيب عازل حراري</td><td>تويوتا كامري</td><td>2024-04-10</td><td>10:00 ص</td><td><span class="badge badge-gold">قادم</span></td></tr>
      <tr><td>2</td><td>تلميع احترافي</td><td>لكزس ES350</td><td>2024-03-20</td><td>2:00 م</td><td><span class="badge badge-green">مكتمل</span></td></tr>
    </tbody></table>
  </div>
</div>
<script src="../assets/js/app.js"></script></body></html>