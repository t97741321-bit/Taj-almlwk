-- =========================================
-- TAJ ALMULOOK Database
-- تاج الملوك لزينة السيارات
-- =========================================
CREATE DATABASE IF NOT EXISTS taj_almulook CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE taj_almulook;

CREATE TABLE users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  fullname VARCHAR(150),
  email VARCHAR(150) UNIQUE,
  phone VARCHAR(20),
  password VARCHAR(255),
  role ENUM('admin','employee','customer') DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cars(
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  brand VARCHAR(100),
  model VARCHAR(100),
  year VARCHAR(10),
  plate VARCHAR(20),
  vin VARCHAR(100),
  color VARCHAR(50),
  image VARCHAR(255),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE categories(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  icon VARCHAR(50)
);

CREATE TABLE services(
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200),
  description TEXT,
  price DECIMAL(10,2),
  image VARCHAR(255),
  icon VARCHAR(50)
);

CREATE TABLE products(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200),
  description TEXT,
  price DECIMAL(10,2),
  old_price DECIMAL(10,2),
  stock INT DEFAULT 0,
  image VARCHAR(255),
  brand VARCHAR(100),
  category_id INT,
  rating DECIMAL(3,1) DEFAULT 5.0,
  FOREIGN KEY(category_id) REFERENCES categories(id)
);

CREATE TABLE orders(
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  total DECIMAL(10,2),
  status ENUM('pending','confirmed','processing','delivered','cancelled') DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE order_items(
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  product_id INT,
  qty INT,
  price DECIMAL(10,2),
  FOREIGN KEY(order_id) REFERENCES orders(id),
  FOREIGN KEY(product_id) REFERENCES products(id)
);

CREATE TABLE bookings(
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  car_id INT,
  service_id INT,
  booking_date DATE,
  booking_time TIME,
  notes TEXT,
  status ENUM('pending','confirmed','done','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(service_id) REFERENCES services(id)
);

CREATE TABLE warranties(
  id INT AUTO_INCREMENT PRIMARY KEY,
  warranty_no VARCHAR(50) UNIQUE,
  user_id INT,
  car_id INT,
  service VARCHAR(200),
  product VARCHAR(200),
  technician VARCHAR(100),
  install_date DATE,
  expire_date DATE,
  status ENUM('ساري','منتهي','ملغي') DEFAULT 'ساري',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE payments(
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  order_id INT,
  amount DECIMAL(10,2),
  method ENUM('cash','card','transfer','stc_pay') DEFAULT 'cash',
  status ENUM('pending','paid','refunded') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications(
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  title VARCHAR(200),
  message TEXT,
  status TINYINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE settings(
  id INT AUTO_INCREMENT PRIMARY KEY,
  shop_name VARCHAR(255) DEFAULT 'تاج الملوك',
  phone VARCHAR(30),
  email VARCHAR(255),
  address TEXT,
  logo VARCHAR(255),
  whatsapp VARCHAR(30),
  instagram VARCHAR(100),
  snapchat VARCHAR(100),
  tiktok VARCHAR(100)
);

CREATE TABLE roles(
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50),
  label VARCHAR(100)
);

CREATE TABLE permissions(
  id INT AUTO_INCREMENT PRIMARY KEY,
  role_id INT,
  permission VARCHAR(100),
  FOREIGN KEY(role_id) REFERENCES roles(id)
);

-- ========== DATA ==========
INSERT INTO roles(name,label) VALUES('admin','مدير'),('employee','موظف'),('customer','عميل');

INSERT INTO settings(shop_name,phone,email,address,whatsapp) VALUES(
  'تاج الملوك لزينة السيارات',
  '782222919',
  'al_zubair_20@instagram.com',
  'اليمن - صنعاء',
  '782222919'
);

INSERT INTO categories(name,icon) VALUES
('شاشات','fa-tv'),('سماعات','fa-volume-high'),('كاميرات','fa-camera'),
('عازل حراري','fa-sun'),('أفلام الحماية','fa-shield'),
('إكسسوارات','fa-star'),('إضاءة LED','fa-lightbulb'),('زينة داخلية','fa-car');

INSERT INTO services(title,description,price,icon) VALUES
('تركيب العازل الحراري','أفضل أنواع العازل الحراري لحماية سيارتك من الحرارة',800,'fa-sun'),
('أفلام الحماية PPF','حماية كاملة لطلاء سيارتك من الخدوش والحوادث الصغيرة',1500,'fa-shield'),
('أنظمة الصوت Pioneer','تركيب أفضل أنظمة الصوت من Pioneer',600,'fa-volume-high'),
('الشاشات الذكية','شاشات أندرويد بأحدث التقنيات',900,'fa-tv'),
('الكاميرات','كاميرات أمامية وخلفية عالية الدقة',400,'fa-camera'),
('إضاءة LED','إضاءة داخلية وخارجية احترافية',300,'fa-lightbulb'),
('التلميع الاحترافي','تلميع سيارتك لإعادة لمعانها',500,'fa-sparkles'),
('تظليل السيارات','تظليل احترافي بأعلى جودة',700,'fa-car-side'),
('السنتر لوك','تركيب قفل مركزي للسيارة',250,'fa-lock'),
('البرمجة','برمجة السيارات وإعداد الأنظمة',350,'fa-microchip');

INSERT INTO products(name,description,price,old_price,stock,brand,category_id,rating) VALUES
('شاشة Pioneer DMH-9600NEX 9 بوصة','شاشة أندرويد بالميزات الكاملة CarPlay وAndroid Auto',1200,1500,15,'Pioneer',1,4.9),
('سماعات Pioneer TS-A6960F 6x9','سماعات عالية الجودة بقدرة 600 واط',280,380,30,'Pioneer',2,4.8),
('كاميرا خلفية Sony 4K','كاميرا رؤية خلفية بدقة 4K مع رؤية ليلية',380,480,20,'Sony',3,4.7),
('عازل حراري 3M Ceramic','عازل حراري سيراميك يحجب 99% من الأشعة فوق البنفسجية',800,1000,10,'3M',4,5.0),
('فيلم حماية PPF 3M كامل','حماية كاملة للسيارة من الخدوش والحجارة',2000,2500,8,'3M',5,4.9),
('إضاءة LED داخلية RGB','إضاءة داخلية ملونة مع ريموت تحكم',150,220,50,'Caronic',7,4.6),
('مكبر صوت Pioneer GM-D9705','مضخم 5 قنوات بقوة 2000 واط',950,1200,12,'Pioneer',2,4.8),
('كاميرا أمامية 360 درجة','كاميرا محيطية بزاوية 360 درجة',650,850,15,'Caronic',3,4.7);

INSERT INTO users(fullname,email,phone,password,role) VALUES
('Administrator','admin@taj.com','0780687704','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin');

INSERT INTO warranties(warranty_no,user_id,car_id,service,product,technician,install_date,expire_date,status) VALUES
('TM001',1,NULL,'تركيب PPF كامل','فيلم حماية 3M PPF','فيصل الغامدي','2024-01-15','2026-01-15','ساري'),
('TM002',1,NULL,'تركيب شاشة أندرويد','Pioneer DMH-9600','محمد الزهراني','2024-03-10','2025-03-10','ساري'),
('TM003',1,NULL,'تظليل كامل سيراميك','عازل 3M Ceramic','عمر السبيعي','2023-08-22','2024-08-22','منتهي');
