<?php
$host="localhost";
$user="root";
$pass="";
$db="taj_almulook";
$conn=new mysqli($host,$user,$pass,$db);
if($conn->connect_error)die("Database Error: ".$conn->connect_error);
$conn->set_charset("utf8mb4");
?>
